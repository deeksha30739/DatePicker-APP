package com.example.datepicker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    Button btn , btn2;

    TextView tvDate;

    DatePicker datePicker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        tvDate = findViewById(R.id.tvDate);
        datePicker=findViewById(R.id.datePicker);



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {tvDate.setText("Change Date" + callDeekshaForDate());}
        });
        btn2=findViewById(R.id.btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();

                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

             DatePickerDialog datePickerDialog = new DatePickerDialog(
                     MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                 @Override
                 public void onDateSet(DatePicker view, int year,
                                       int monthOfyear, int dayOfMonth) {
                      tvDate.setText(dayOfMonth + "-" + (monthOfyear + 1) + "-"+ year );

                 }
             },

                          year, month, day);
                     datePickerDialog.show();

            }
        });
    }

    private String callDeekshaForDate() {


        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(datePicker.getMonth() + 1 + "/");
        stringBuilder.append(datePicker.getDayOfMonth() + 1 + "/");


        return stringBuilder.toString();
    }
}